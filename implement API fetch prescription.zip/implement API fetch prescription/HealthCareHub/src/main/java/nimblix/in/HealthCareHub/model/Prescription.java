package nimblix.in.HealthCareHub.model;

public class Prescription {
}
