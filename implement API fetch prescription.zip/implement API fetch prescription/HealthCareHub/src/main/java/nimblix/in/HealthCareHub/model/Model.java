package nimblix.in.HealthCareHub.model;

public @interface Model {
}
