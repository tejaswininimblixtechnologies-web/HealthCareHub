package nimblix.in.HealthCareHub.repository;

import nimblix.in.HealthCareHub.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByPhoneNumber(String phoneNumber);

    Optional<User> findByEmail(String email);
}
