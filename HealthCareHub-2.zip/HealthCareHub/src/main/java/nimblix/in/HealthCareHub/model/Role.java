package nimblix.in.HealthCareHub.model;

public enum Role {
    DOCTOR,
    PATIENT
}
