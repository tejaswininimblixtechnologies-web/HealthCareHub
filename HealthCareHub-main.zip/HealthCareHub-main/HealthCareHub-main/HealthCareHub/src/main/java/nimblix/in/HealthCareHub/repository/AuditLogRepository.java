package nimblix.in.HealthCareHub.repository;

import nimblix.in.HealthCareHub.model.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}

