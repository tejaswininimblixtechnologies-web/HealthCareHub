package nimblix.in.HealthCareHub.service;

public interface DoctorService {
}
